## Plugins Used In Self Bot..!!!

**Plugins Are Used In This Self Bot Are....**

***1.*** ***Aclarity***
 
## alacritty-nuker  

**best & fastest nuker on cord, src.**

**100% created by aced & dropout.**

**Download Link:- https://github.com/RisinPlayZ/alacritty-nuker**


***2.*** ***Karamveer Nuker***

## KaramveerNuker

**Fasted Nuker 50 Bans Per Second**

***Many Things In This Nuker Created By KaramveerPlayZ 🖤👑🍷KaramveerPlayZ Op Forver!!***


**Created By KaramveerPlayZ**

**Download Link:- https://github.com/KaramveerMalhotra/Karamveer-NukerV2**

